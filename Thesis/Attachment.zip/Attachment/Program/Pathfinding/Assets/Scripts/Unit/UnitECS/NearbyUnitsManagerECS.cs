using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.Burst;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using Unity.Jobs;
using UnityEngine;
using UnityEngine.UIElements;
using utils;

/// <summary>
/// Finds the nearby units and computes steering forces for them
/// </summary>
public class NearbyUnitsManagerECS
{
    public NativeArray<int> unitsMap;
    public int mapWidth;
    public int mapHeight;

    /// <summary>
    /// Creates the map of units in a NativeArray
    /// </summary>
    /// <param name="units"></param>
    /// <param name="newMap"></param>
    public void Initialize(List<Unit> units, bool newMap)
    {
        if (newMap)
        {
            mapWidth = 2 * Map.instance.passabilityMap.GetLength(0);
            mapHeight = 2 * Map.instance.passabilityMap.GetLength(1);
            unitsMap = new NativeArray<int>(mapWidth * mapHeight, Allocator.Persistent);

            for (int i = 0; i < unitsMap.Length; i++)
            {
                unitsMap[i] = -1;
            }
        }

        for (int i = 0; i < units.Count; i++)
        {
            Vector2 unitPosition = units[i].position;
            int X = Mathf.FloorToInt(unitPosition.x * 2);
            int Y = Mathf.FloorToInt(unitPosition.y * 2);
            unitsMap[X + Y * mapWidth] = i;
        }
    }

    /// <summary>
    /// Updates the unit positions
    /// </summary>
    /// <param name="unitPositions"></param>
    public void SetUnitPositions(NativeList<Vector2> unitPositions)
    {
        JobHandle positionsJobHandle;
        SetPositionsJob positionsJob;

        positionsJob = new SetPositionsJob()
        {
            unitsMap = unitsMap,
            mapWidth = mapWidth,
            mapHeight = mapHeight,
            unitPositions = unitPositions,
        };

        positionsJobHandle = positionsJob.Schedule(unitPositions.Length, 64);
        positionsJobHandle.Complete();
    }

    /// <summary>
    /// Updates the unit positions
    /// </summary>
    [BurstCompile]
    private struct SetPositionsJob : IJobParallelFor
    {
        [NativeDisableContainerSafetyRestriction]
        public NativeArray<int> unitsMap;
        [ReadOnly]
        public int mapWidth;
        [ReadOnly]
        public int mapHeight;

        [ReadOnly]
        public NativeList<Vector2> unitPositions;

        public void Execute(int index)
        {
            Vector2 unitPosition = unitPositions[index];
            int X = Mathf.FloorToInt(unitPosition.x * 2);
            int Y = Mathf.FloorToInt(unitPosition.y * 2);
            unitsMap[X + Y * mapWidth] = index;
        }
    }

    /// <summary>
    /// Removes the unit positions from the map
    /// </summary>
    /// <param name="unitPositions"></param>
    public void CleanUnitTiles(NativeList<Vector2> unitPositions)
    {
        JobHandle positionsJobHandle;
        CleanPositionsJob positionsJob;

        positionsJob = new CleanPositionsJob()
        {
            unitsMap = unitsMap,
            mapWidth = mapWidth,
            mapHeight = mapHeight,
            unitPositions = unitPositions,
        };

        positionsJobHandle = positionsJob.Schedule(unitPositions.Length, 64);
        positionsJobHandle.Complete();
    }

    /// <summary>
    /// Removes the unit positions from the map
    /// </summary>
    [BurstCompile]
    private struct CleanPositionsJob : IJobParallelFor
    {
        [NativeDisableContainerSafetyRestriction]
        public NativeArray<int> unitsMap;
        [ReadOnly]
        public int mapWidth;
        [ReadOnly]
        public int mapHeight;

        [ReadOnly]
        public NativeList<Vector2> unitPositions;

        public void Execute(int index)
        {
            Vector2 unitPosition = unitPositions[index];
            int X = Mathf.FloorToInt(unitPosition.x * 2);
            int Y = Mathf.FloorToInt(unitPosition.y * 2);

            for (int i = -1; i < 2; i++)
            {
                for (int j = -1; j < 2; j++)
                {
                    int clearingIndex = X + i + (Y + j) * mapWidth;
                    if (clearingIndex >= 0 && clearingIndex <= unitsMap.Length)
                    {
                        unitsMap[clearingIndex] = -1;
                    }
                }
            }
        }
    }

    /// <summary>
    /// Updates the unit positions on the map
    /// </summary>
    /// <param name="unitPositions"></param>
    public void UpdateUnitPositions(NativeList<Vector2> unitPositions)
    {
        JobHandle positionsJobHandle;
        UpdatePositionsJob positionsJob;

        positionsJob = new UpdatePositionsJob()
        {
            unitsMap = unitsMap,
            mapWidth = mapWidth,
            mapHeight = mapHeight,
            unitPositions = unitPositions,
        };

        positionsJobHandle = positionsJob.Schedule(unitPositions.Length, 64);
        positionsJobHandle.Complete();
    }

    /// <summary>
    /// Updates the unit positions on the map
    /// </summary>
    [BurstCompile]
    private struct UpdatePositionsJob : IJobParallelFor
    {
        [NativeDisableContainerSafetyRestriction]
        public NativeArray<int> unitsMap;
        [ReadOnly]
        public int mapWidth;
        [ReadOnly]
        public int mapHeight;

        [ReadOnly]
        public NativeList<Vector2> unitPositions;

        public void Execute(int index)
        {
            Vector2 unitPosition = unitPositions[index];
            int X = Mathf.FloorToInt(unitPosition.x * 2);
            int Y = Mathf.FloorToInt(unitPosition.y * 2);

            for (int i = -1; i < 2; i++)
            {
                for (int j = -1; j < 2; j++)
                {
                    int clearingIndex = X + i + (Y + j) * mapWidth;
                    if (clearingIndex >= 0 && clearingIndex <= unitsMap.Length && unitsMap[clearingIndex] == index)
                    {
                        unitsMap[clearingIndex] = -1;
                    }
                }
            }

            unitsMap[X + Y * mapWidth] = index;
        }
    }

    /// <summary>
    /// Computes the steering forces for all of the units
    /// </summary>
    /// <param name="unitPositions"></param>
    /// <param name="unitVelocities"></param>
    /// <param name="desiredVelocities">Velocities based solely on the seek force</param>
    /// <param name="deltaTime"></param>
    /// <returns>NativeArrays with separation, alignment and avoidance forces</returns>
    public (NativeArray<Vector2> separationForces, NativeArray<Vector2> alignmentForces, NativeArray<Vector2> avoidanceForces) GetNearbyUnitsForces(NativeList<Vector2> unitPositions, NativeList<Vector2> unitVelocities, NativeList<Vector2> desiredVelocities, float deltaTime)
    {
        NativeArray<Vector2> separationForces = new NativeArray<Vector2>(unitPositions.Length, Allocator.TempJob);
        NativeArray<Vector2> alignmentForces = new NativeArray<Vector2>(unitPositions.Length, Allocator.TempJob);
        NativeArray<Vector2> avoidanceForces = new NativeArray<Vector2>(unitPositions.Length, Allocator.TempJob);
        JobHandle unitForcesJobHandle;
        NearbyUnitForcesJob unitForcesJob;

        unitForcesJob = new NearbyUnitForcesJob()
        {
            deltaTime = deltaTime,
            unitsMap = unitsMap,
            mapWidth = mapWidth,
            mapHeight = mapHeight,
            maxForce = SimulationSettings.MaxForce,
            unitRadius = SimulationSettings.UnitRadius,
            unitPositions = unitPositions,
            unitVelocities = unitVelocities,
            desiredVelocities = desiredVelocities,

            separationForces = separationForces,
            alignmentForces = alignmentForces,
            avoidanceForces = avoidanceForces
        };

        unitForcesJobHandle = unitForcesJob.Schedule(unitPositions.Length, 64);
        unitForcesJobHandle.Complete();

        return (separationForces, alignmentForces, avoidanceForces);
    }

    /// <summary>
    /// Computes the steering forces based on the nearby units
    /// </summary>
    [BurstCompile]
    private struct NearbyUnitForcesJob : IJobParallelFor
    {
        public float deltaTime;
        [ReadOnly]
        public NativeArray<int> unitsMap;
        [ReadOnly]
        public int mapWidth;
        [ReadOnly]
        public int mapHeight;
        [ReadOnly]
        public float maxForce;
        [ReadOnly]
        public float unitRadius;

        [ReadOnly]
        public NativeList<Vector2> unitPositions;
        [ReadOnly]
        public NativeList<Vector2> unitVelocities;
        [ReadOnly]
        public NativeList<Vector2> desiredVelocities;

        public NativeArray<Vector2> separationForces;
        public NativeArray<Vector2> alignmentForces;
        public NativeArray<Vector2> avoidanceForces;

        public void Execute(int index)
        {
            Vector2 unitPosition = unitPositions[index];
            (int X, int Y) currentCoord = (Mathf.FloorToInt(unitPosition.x * 2), Mathf.FloorToInt(unitPosition.y * 2));
            NativeList<(Vector2 position, Vector2 velocity, Vector2 desiredVelocity, int otherUnitID)> nearbyUnits = new NativeList<(Vector2 position, Vector2 velocity, Vector2 desiredVelocity, int otherUnitID)>(50, Allocator.Temp);
            for (int i = Mathf.Max(currentCoord.X - 5, 0); i < Mathf.Min(currentCoord.X + 6, mapWidth); i++)
            {
                for (int j = Mathf.Max(currentCoord.Y - 5, 0); j < Mathf.Min(currentCoord.Y + 6, mapHeight); j++)
                {
                    if ((i != currentCoord.X || j != currentCoord.Y) && unitsMap[i + j * mapWidth] != -1)
                    {
                        int unitIndex = unitsMap[i + j * mapWidth];
                        nearbyUnits.Add((unitPositions[unitIndex], unitVelocities[unitIndex], desiredVelocities[unitIndex], unitIndex));
                    }
                }
            }

            separationForces[index] = getSeparationForce(index, nearbyUnits);
            alignmentForces[index] = getAlignmentForce(index, nearbyUnits);
            avoidanceForces[index] = getUnitAvoidanceForce(index, nearbyUnits);
            nearbyUnits.Dispose();
        }

        private Vector2 getUnitAvoidanceForce(int index, NativeList<(Vector2 position, Vector2 velocity, Vector2 desiredVelocity, int otherUnitID)> nearbyUnits)
        {
            var overallAvoidanceForce = Vector2.zero;
            foreach ((Vector2 position, Vector2 velocity, Vector2 desiredVelocity, int otherUnitID) unit in nearbyUnits)
            {
                if (Vector2.Distance(unitPositions[index], unit.position) < 1.6f * 2 * unitRadius)
                {
                    Vector2 avoidanceForce = GetVelocitySteeringFromAnotherUnit(index, unit);
                    //Vector2 avoidanceForce = GetSteeringFromAnotherUnit(index, unit);
                    overallAvoidanceForce += avoidanceForce;
                }
            }
            return overallAvoidanceForce.LimitMagnitude(maxForce);
        }

        private Vector2 GetSteeringFromAnotherUnit(int index, (Vector2 position, Vector2 velocity, Vector2 desiredVelocity, int otherUnitID) otherUnit)
        {
            var relativePosition = (unitPositions[index]) - otherUnit.position;
            //var relativeVelocity = (unitVelocities[index] - otherUnit.velocity);
            var relativeVelocity = (desiredVelocities[index] - otherUnit.desiredVelocity);
            float timeToCollision = (relativePosition.magnitude - 2 * SimulationSettings.UnitRadius) / relativeVelocity.magnitude;
            //Debug.Log($"angle1 {Vector2.SignedAngle(relativePosition, relativeVelocity)}, angle2 {Vector2.SignedAngle(relativePosition, relativeVelocity)}");

            if (Geometry.CircleIntersectsRay(relativePosition, relativePosition + relativeVelocity, 2 * SimulationSettings.UnitRadius))
            {
                relativePosition.Normalize();
                relativeVelocity.Normalize();
                Vector2 direction;
                if (Vector2.SignedAngle(relativePosition, relativeVelocity) > 0)
                {
                    direction = relativePosition.Rotate(90);
                }
                else
                {
                    direction = relativePosition.Rotate(-90);
                }
                return direction;
            }
            else
            {
                return Vector2.zero;
            }
        }

        private Vector2 GetVelocitySteeringFromAnotherUnit(int index, (Vector2 position, Vector2 velocity, Vector2 desiredVelocity, int otherUnitID) otherUnit)
        {
            var collidingRadius = 2 * unitRadius;
            collidingRadius *= 1;
            var relativePosition = (unitPositions[index]) - /*(otherUnit.otherUnitID < index ? otherUnit.position + otherUnit.velocity * deltaTime : */otherUnit.position;
            var relativeVelocity = (unitVelocities[index] - otherUnit.velocity);

            var possibleCollisionAtStep = relativePosition.magnitude / relativeVelocity.magnitude;

            //if (possibleCollisionAtStep > LOOKAHEAD)
            //    return Vector2.Zero;

            if (Geometry.CircleIntersectsRay(relativePosition, relativePosition + relativeVelocity, collidingRadius))
            {
                float angle = Utilities.Modulo2Pi(relativeVelocity.ToAngle() - Mathf.PI / 2);
                if (angle == 0)
                {
                    uint seed = (uint)index + (uint)(otherUnit.position.x * 1352484635 + otherUnit.position.y * 24622789637);
                    if (seed == 0) seed = 42;
                    angle = new Unity.Mathematics.Random(seed).NextFloat(-1.0f, 1.0f) * 0.001f + angle;
                }

                var normal = GetVelocityAvoidanceDirectionVector(relativePosition, angle, collidingRadius, relativeVelocity);
                return normal;
            }
            else
            {
                return Vector2.zero;
            }
        }

        /// <summary>
        /// Computes the turn vector to avoid collision in ORCA (does not handle same direction approach of different speed moving object)
        /// </summary>
        /// <param name="relativePosition"></param>
        /// <param name="angle"></param>
        /// <param name="collidingRadius"></param>
        /// <param name="relativeVelocity"></param>
        /// <param name="size">how much steering is necessary</param>   
        /// <returns></returns>
        private Vector2 GetVelocityAvoidanceDirectionVector(Vector2 relativePosition, float angle, float collidingRadius, Vector2 relativeVelocity)
        {
            Vector2 horizontalIntersection = Geometry.GetHorizontalIntersection(relativePosition, angle, 0);
            Vector2 verticalIntersection = Geometry.GetVerticalIntersection(relativePosition, angle, 0);

            Vector2 intersection = Mathf.Abs(horizontalIntersection.x) < Mathf.Abs(verticalIntersection.y)
                        ? horizontalIntersection
                        : verticalIntersection;

            if (intersection == verticalIntersection)
            {
                if (relativeVelocity.x * verticalIntersection.y < 0)
                    return relativeVelocity.Rotate(-90);
                return relativeVelocity.Rotate(90);
            }
            else
            {
                if (relativeVelocity.y * horizontalIntersection.x > 0)
                    return relativeVelocity.Rotate(-90);
                return relativeVelocity.Rotate(90);
            }
        }

        /// <summary>
        /// the unit is repulsed by the nearby units (closer the unit stronger the force)
        /// </summary>
        /// <param name="index"></param>
        /// <param name="nearbyUnits"></param>
        /// <returns></returns>
        private Vector2 getSeparationForce(int index, NativeList<(Vector2 position, Vector2 velocity, Vector2 desiredVelocity, int otherUnitID)> nearbyUnits)
        {
            Vector2 aggregateForce = Vector2.zero;
            foreach ((Vector2 position, Vector2 velocity, Vector2 desiredVelocity, int otherUnitID) unit in nearbyUnits)
            {
                Vector2 oneUnitForce = getOneUnitSeparationForce(index, unit);
                aggregateForce += oneUnitForce;
            }
            return aggregateForce;
        }

        private Vector2 getOneUnitSeparationForce(int index, (Vector2 position, Vector2 velocity, Vector2 desiredVelocity, int otherUnitID) otherUnit)
        {
            Vector2 offset = (unitPositions[index] + deltaTime * unitVelocities[index]) - (otherUnit.position + otherUnit.velocity * deltaTime);
            //Vector2 offset = unitPositions[index] - (otherUnit.position + (otherUnit.otherUnitID < index ? otherUnit.velocity * deltaTime : Vector2.zero));
            float distance = offset.magnitude;
            float distanceBounds = distance - 2 * unitRadius;
            if (distance != 0) offset.Normalize();
            Vector2 maxForce2 = maxForce * offset;

            //Units collide with each other
            if (distanceBounds <= 0) return maxForce2;

            Vector2 repulsiveForce;
            if (distance != 0)
            {
                repulsiveForce = maxForce2 * SeparationForceCalculator(distanceBounds / 1.0f);
                return repulsiveForce;
            }
            return Vector2.zero;
        }

        /// <summary>
        /// Separation force based on the distance between the unit (very shapr increase at close proximity)
        /// </summary>
        /// <param name="boundsDistance"></param>
        /// <returns></returns>
        private float SeparationForceCalculator(float boundsDistance)
        {
            float factor = Mathf.Clamp01(1.0f - boundsDistance);
            float factor2 = Mathf.Clamp01(3*factor-2)*2 + 1;
            return Mathf.Max(factor2 * factor2 * factor * factor * factor * factor * factor * factor, factor * factor * 0.25f);
        }

        /// <summary>
        /// Mimic the behavior of nearby units
        /// </summary>
        /// <param name="index"></param>
        /// <param name="nearbyUnits"></param>
        /// <returns></returns>
        private Vector2 getAlignmentForce(int index, NativeList<(Vector2 position, Vector2 velocity, Vector2 desiredVelocity, int otherUnitID)> nearbyUnits)
        {
            Vector2 sum = Vector2.zero;
            foreach ((Vector2 position, Vector2 velocity, Vector2 desiredVelocity, int otherUnitID) unit in nearbyUnits) sum += unit.velocity;
            if (sum.magnitude == 0) return sum;
            Vector2 desiredVelocity = sum / nearbyUnits.Length;
            return (desiredVelocity - unitVelocities[index]).LimitMagnitude(maxForce);
        }
    }

    public void Clean()
    {
        unitsMap.Dispose();
    }
}
