using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnitVisualization : MonoBehaviour
{
    private SpriteRenderer rndr;

    /// <summary>
    /// Colors that can be applied to the unit (based on its flow stream)
    /// </summary>
    private List<Color> colors = new List<Color>
    {
        Color.red, Color.blue, Color.green, Color.yellow, Color.magenta, Color.cyan,
        new Color(1.0f, 0.5f, 0.0f), new Color(1.0f, 0.0f, 0.5f), new Color(0.5f, 1.0f, 0.0f),
        new Color(0.0f, 1.0f, 0.5f), new Color(0.5f, 0.0f, 1.0f), new Color(0.0f, 0.5f, 1.0f),
        new Color(0.5f, 0.5f, 0.0f), new Color(0.5f, 0.0f, 0.5f), new Color(0.5f, 0.5f, 0.0f),
        new Color(0.0f, 0.0f, 0.5f), new Color(0.5f, 0.0f, 0.0f), new Color(0.0f, 0.5f, 0.0f),
    };
    public Vector2 position { 
        get {  return transform.position; } 
        set { transform.position = value; }
    }

    private void Start()
    {
        rndr = GetComponent<SpriteRenderer>();
        SetColor(Color.red);
    }
    public void Remove()
    {
        position = new Vector2(-1000, -1000);
        Destroy(gameObject);
    }

    /// <summary>
    /// Change color based on the index of the stream the unit belongs to
    /// </summary>
    /// <param name="index"></param>
    public void SetColor(int index) {
        if (index < colors.Count) rndr.material.color = colors[index];
        else rndr.material.color = Color.black;
    }

    public void SetColor(Color color)
    {
        rndr.material.color = color;
    }
}
