using System.Collections.Generic;
using UnityEngine;
using utils;

/// <summary>
/// Class representing a single unit. Manages the steering, interactions with the walls and other units.
/// It also records movement data which will be used to generate the run's output (results)
/// </summary>
public class Unit
{
    /// <summary>
    /// Stores the positions on the path the unit took
    /// </summary>
    public List<Vector2> pathPositions = new List<Vector2>();
    /// <summary>
    /// Records the information about the times the unit arrived at a gate
    /// </summary>
    public List<(int gateID, (float ArrivalTime, float distanceFromStart, int StreamID, Vector2 ArrivalPosition))> gatePathMovement = new List<(int gateID, (float ArrivalTime, float distanceFromStart, int StreamID, Vector2 ArrivalPosition))>();
    private float distanceFromStart = 0.0f;
    private float timeElapsed = 0.0f;
    private float deltaTime;
    public const float pathPositionsUpdatePeriod = 1.0f;
    /// <summary>
    /// Unique identifier of the unit
    /// </summary>
    public int ID;
    private Target target;
    float checkIfReachedTargetInterval = 0;

    public Vector2 position;
    private Vector2 position2;
    public Vector2 velocity;
    public Vector2 desiredVelocity;

    private float maxSpeed;
    [HideInInspector]
    public Coord currentCoord;
    private FlowField flowField;
    private PathExecutor pathExecutor;
    private RegionalPathExecutor regionalPathExecutor;
    private RegionalFlowGraphPathExecutor regionalFlowGraphPathExecutor;
    private RegionalFlowGraphPathUsingSubPathsExecutor regionalFlowGraphPathUsingSubPathsExecutor;
    private FlowFieldSupremeCommander flowFieldSupremeCommander;
    private NearbyUnitsManager nearbyUnitsManager;
    private RegionalDecomposition regionalDecomposition;
    private int streamID = 0;
    [HideInInspector]
    public int repaths = 0;
    [HideInInspector]
    public int softRepaths = 0;

    public MovementMode movementMode;

    public void SetRegionalDecomposition(RegionalDecomposition decomposition)
    {
        regionalDecomposition = decomposition;
    }

    public Unit(int ID)
    {
        this.ID = ID;
    }

    /// <summary>
    /// Set the unit's position, create the NearbyUnitsManager
    /// </summary>
    /// <param name="pos"></param>
    public void Initialize(Vector2 pos)
    {
        position = pos;
        currentCoord = Coord.CoordFromPosition(pos);
        ChangeCoord(position);
        nearbyUnitsManager = new NearbyUnitsManager(this);
        maxSpeed = SimulationSettings.UnitSpeed;
    }

    /// <summary>
    /// Get the units velocity based on the steering force and the delta time
    /// </summary>
    /// <param name="force"></param>
    /// <param name="deltaTime"></param>
    private void ApplyForce(Vector2 force, float deltaTime)
    {
        force = force.LimitMagnitude(SimulationSettings.MaxForce);
        float speed = velocity.magnitude;
        float factor = Mathf.Clamp01(1.0f - (20 - 15 * (speed / maxSpeed)) * deltaTime);
        Vector2 goalVelocity = factor * velocity + (1.0f - factor) * force;
        velocity = goalVelocity.LimitMagnitude(maxSpeed);
    }

    /*
    private Vector2 LimitRotation(Vector2 desiredVelocity)
    {
        float angle = Vector2.Angle(desiredVelocity, velocity);
        Vector2 newVelocity;

        var allowedMaxAngle = SimulationSettings.instance.MaxRotationPerSecond;

        if (angle > allowedMaxAngle)
        {
            var angleVector = GeometryHelper.AngleToVector(allowedMaxAngle);
            newVelocity = angleVector * newVelocity.Length();
        }
        else if (-angle > allowedMaxAngle)
        {
            var angleVector = GeometryHelper.AngleToVector(-allowedMaxAngle);
            newVelocity = angleVector * newVelocity.Length();
        }
        //else; //no change

        return newVelocity;
    }
    */

    /// <summary>
    /// Seek forces for different movement methods
    /// </summary>
    /// <param name="deltaTime"></param>
    /// <returns></returns>
    public Vector2 GetSeekForce(float deltaTime)
    {
        Vector2 seek;

        switch (movementMode)
        {
            case MovementMode.FlowField:
                seek = flowField.getMovementDirection(position);
                break;
            case MovementMode.AStar:
                if (pathExecutor != null) seek = pathExecutor.GetPathFollowingForce(deltaTime);
                else seek = Vector2.zero;
                break;
            case MovementMode.SupremeCommanderFlowField:
                seek = flowFieldSupremeCommander.GetFlowFieldDirection(position, deltaTime);
                break;
            case MovementMode.RegionalPath:
                seek = regionalPathExecutor.GetSeekForce(deltaTime);
                break;
            case MovementMode.RegionalFlowGraph:
                seek = regionalFlowGraphPathExecutor.GetSeekForce(deltaTime);
                break;
            case MovementMode.RegionalFlowGraphPaths:
                seek = regionalFlowGraphPathUsingSubPathsExecutor.GetSeekForce(deltaTime);
                break;
            default:
                seek = Vector2.zero;
                break;
        }

        return seek;
    }

    /// <summary>
    /// Compute the steering forces and create their weighted combination
    /// </summary>
    /// <param name="deltaTime"></param>
    /// <returns></returns>
    public Vector2 ComputeForces(float deltaTime)
    {
        Vector2 seek = GetSeekForce(deltaTime);
        desiredVelocity = SimulationSettings.UnitSpeed * seek;

        Vector2 separationForce, alignmentForce, unitTurningForce;
        nearbyUnitsManager.GetNearbyUnitsForces(deltaTime, out separationForce, out alignmentForce, out unitTurningForce);
 
        Vector2 wallRepulsionForce = Map.instance.walls.GetWallRepulsionForce(this);
        Vector2 wallTurningForce = Map.instance.walls.GetWallTurningForce(this);

        Vector2 combination =
            10.0f * seek +
            100.0f * separationForce +
            50.0f * wallRepulsionForce +
            10.0f * wallTurningForce +
            5.0f * unitTurningForce +
            0.5f * alignmentForce;

        return combination.LimitMagnitude(SimulationSettings.MaxForce);
    }

    /// <summary>
    /// Get the unit's new position based on the steering force.
    /// Check if the new position overlaps with another unit or the wall and react accordingly.
    /// </summary>
    /// <param name="deltaTime"></param>
    /// <param name="force"></param>
    public void CalculateNewPosition(float deltaTime, Vector2 force)
    {
        ApplyForce(force, deltaTime);
        Vector2 movement = velocity * deltaTime;
        Vector2 newPosition = new Vector2(position.x + movement.x, position.y + movement.y);
        Vector2 newPositionX = new Vector2(position.x + movement.x, position.y);
        Vector2 newPositionY = new Vector2(position.x, position.y + movement.y);
        if (Map.instance.walls.IsInWallsUnit(position))
        {
            Debug.Log("Unit in the walls");
        }
        if (Map.instance.walls.IsInWallsUnit(newPosition) && !Map.instance.walls.IsInWallsUnit(newPositionX))
        {
            newPosition = newPositionX;
        }
        else if (Map.instance.walls.IsInWallsUnit(newPosition) && !Map.instance.walls.IsInWallsUnit(newPositionY))
        {
            newPosition = newPositionY;
        }

        if (!Map.instance.walls.IsInWallsUnit(newPosition) && !nearbyUnitsManager.NearbyPositionOccupied(newPosition)) {
            position2 = newPosition;
            ChangeCoord(position2);
            TargetReachedTestAndResponse(deltaTime);
        }
    }

    /// <summary>
    /// Test if the unit reached the target, if so inform the Simulator
    /// </summary>
    /// <param name="deltaTime"></param>
    public void TargetReachedTestAndResponse(float deltaTime)
    {
        bool reachedTarget = CheckIfReachedTarget(deltaTime);
        if (reachedTarget)
        {
            Simulator.Instance.UnitReachedTarget(this);
            currentCoord.UnitsAtTile().Remove(this);
        }
    }

    public void UpdatePosition()
    {
        position = position2;
    }

    /// <summary>
    /// update the unit's coord based on its position
    /// </summary>
    /// <param name="position"></param>
    public void ChangeCoord(Vector2 position)
    {
        Coord newCoord = Coord.CoordFromPosition(position);
        if (currentCoord != newCoord)
        {
            currentCoord.UnitsAtTile().Remove(this);
            newCoord.UnitsAtTile().Add(this);
            currentCoord = newCoord;
        }
    }

    /// <summary>
    /// Move to a target using A*
    /// </summary>
    /// <param name="target"></param>
    /// <returns></returns>
    public bool MoveTo(Vector2 target)
    {
        Stack<Vector2> path = Pathfinding.ConstructPathAStar(position, target, Pathfinding.StepDistance, 0.2f);
        if (path != null && path.Count > 0)
        {
            pathExecutor = new PathExecutor(this, ref path);
            return true;
        }
        return false;
    }

    public void MoveAlongThePath(Stack<Vector2> path)
    {
        pathExecutor = new PathExecutor(this, ref path);
    }

    public void MoveAlongThePath(List<Vector2> path)
    {
        pathExecutor = new PathExecutor(this, ref path);
    }

    public void MoveAlongThePath(List<Vector2> path, int streamID)
    {
        this.streamID = streamID;
        pathExecutor = new PathExecutor(this, ref path);
    }

    public void UseFlowField(FlowField flowField)
    {
        this.flowField = flowField;
    }

    public void UseSupremeCommanderFlowField(FlowFieldSupremeCommander scFlowField)
    {
        flowFieldSupremeCommander = scFlowField;
    }

    public void UseRegionalPath(RegionalPath path)
    {
        regionalPathExecutor = new RegionalPathExecutor(this, path);
    }

    public void UseRegionalFlowGraphPath(RegionalFlowGraphPath graphPath, int startingPath)
    {
        regionalFlowGraphPathExecutor = new RegionalFlowGraphPathExecutor(this, graphPath, startingPath);
    }

    public void UseRegionalFlowGraphPathUsingSubPaths(RegionalFlowGraphPathUsingSubPaths graphPath, int startingPath)
    {
        regionalFlowGraphPathUsingSubPathsExecutor = new RegionalFlowGraphPathUsingSubPathsExecutor(this, graphPath, startingPath);
    }

    public void SetTarget(Target target)
    {
        this.target = target;
    }

    /// <summary>
    /// Periodically record the unit's current position
    /// </summary>
    /// <param name="timeChange"></param>
    public void TryUpdatePathPositions(float timeChange)
    {
        deltaTime += timeChange;
        if (deltaTime >= pathPositionsUpdatePeriod)
        {
            deltaTime -= pathPositionsUpdatePeriod;
            if (pathPositions.Count > 0)
            {
                Vector2 previousPosition = pathPositions[pathPositions.Count-1];
                Vector2 direction = (position - previousPosition).normalized;
                float distance = Vector2.Distance(position,previousPosition);
                if (GateRaycasting.GateRaycast(regionalDecomposition, previousPosition, direction, distance, out Vector2 hitPoint, out float distanceToGate, out int gateID))
                {
                    if (gatePathMovement.FindAll(x => x.gateID == gateID).Count == 0)
                    {
                        float fraction = distanceToGate / distance;
                        int streamIDLocal = 0;
                        if (movementMode == MovementMode.RegionalFlowGraph)
                            streamIDLocal = regionalFlowGraphPathExecutor.pathIndex;
                        else if (movementMode == MovementMode.RegionalFlowGraphPaths)
                            streamIDLocal = regionalFlowGraphPathUsingSubPathsExecutor.pathIndex;
                        else if (movementMode == MovementMode.AStar)
                            streamIDLocal = this.streamID;

                        gatePathMovement.Add((gateID, 
                            (timeElapsed + pathPositionsUpdatePeriod * fraction, 
                            distanceFromStart + distanceToGate,
                            streamIDLocal, hitPoint)));
                    }
                }
                timeElapsed += pathPositionsUpdatePeriod;
                distanceFromStart += distance;
            }
            pathPositions.Add(position);
        }
    }

    private bool CheckIfReachedTarget(float deltaTime)
    {
        bool result = false;
        float distanceToBounds;
        checkIfReachedTargetInterval -= deltaTime;
        if (checkIfReachedTargetInterval <= 0)
        {
            result = target.UnitReachedTarget(this, out distanceToBounds);
            checkIfReachedTargetInterval = distanceToBounds / SimulationSettings.UnitSpeed;
        }
        return result;
    }
}