using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InitialUnitPositions : MonoBehaviour
{
    public List<Coord> startingPositions;
    public Unit unitPrefab;
}
