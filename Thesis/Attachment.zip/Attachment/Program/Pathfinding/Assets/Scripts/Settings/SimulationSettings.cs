using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class SimulationSettings
{
    [HideInInspector]
    public const float UnitRadius = 0.4f;
    public const float UnitSpeed = 2;
    public const float MaxForce = 2;
}
