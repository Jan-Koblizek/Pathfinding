using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class Simulator : MonoBehaviour
{
    /// <summary>
    /// Pathfinding requests that the simulator should run
    /// </summary>
    [Header("Simulation Setup")]
    public List<SimulationSetup> simulationSpecifications;
    public List<MovementMode> movementModesTested;
    /// <summary>
    /// Number of runs for each pathfinding problem and movement mode combination
    /// </summary>
    public int numberOfRuns;
    public bool writeResults;
    public bool automaticSimulation;

    [Header("Graphics")]
    public UnitDisplay unitDisplayMode = UnitDisplay.SingleColor;
    public DecompositionDisplay decompositionDisplay = DecompositionDisplay.None;
    public static Simulator Instance { get; private set; }
    [Header("Prefabs and Components")]
    public UnitMovementManager unitMovementManager;
    public GameObject unitPrefab;
    public GameObject unitsParent;
    public GameObject targetPrefab;
    public GameObject finishedText;


    private int internalMovementCycles = 2;
    private int outerMovementCycles = 5;

    private MovementMode movementMode;
    private float simulationTime;
    private float executionComputationTime;
    private int unitsReachedTarget;
    private int numberOfUnits;
    [HideInInspector]
    public Target target;
    [HideInInspector]
    public List<Vector2> warmUpGoalPositions;
    [HideInInspector]
    public List<Vector2> warmUpStartPositions;

    [HideInInspector]
    public bool simulationStarted = false;
    [HideInInspector]
    public bool simulationFinished = false;
    [HideInInspector]
    public RegionalDecomposition decomposition;

    private bool halfFinished = false;
    private int simulationID;
    private bool failed = false;
    private bool shouldStartSimulation = false;

    [HideInInspector]
    public ExperimentResults experimentResults;


    [HideInInspector]
    public FlowGraphWrapper flowGraphWrapper;
    [HideInInspector]
    public RegionalFlowGraphWrapper regionalFlowGraphWrapper;
    [HideInInspector]
    public RegionalFlowGraphPathsWrapper regionalFlowGraphPathsWrapper;

    private void Start()
    {
        Instance = this;
        StartCoroutine(Simulate());
    }

    /// <summary>
    /// Use wants to run a simulation (this will trigger a new run, if there are some left and there isn't a simulation already running)
    /// </summary>
    public void OnUserStartSimulation()
    {
        shouldStartSimulation = true;
    }

    /// <summary>
    /// Runs all the pathfinding problems supplied
    /// </summary>
    /// <returns></returns>
    IEnumerator Simulate()
    {
        for (int i = 0; i < simulationSpecifications.Count; i++)
        {
            simulationID = i;
            Map.instance.Initialize(simulationSpecifications[i].mapTexture);
            if (target != null) Destroy(target.gameObject);
            target = Target.CreateTarget(simulationSpecifications[i].GetTargetPosition(), simulationSpecifications[i].targetSize, targetPrefab);
            warmUpStartPositions = simulationSpecifications[i].GetWarmUpStartPositions();
            warmUpGoalPositions = simulationSpecifications[i].GetWarmUpGoalPositions();
            yield return StartCoroutine(SimulateOne());
        }
        Debug.Log("Quitting");
        finishedText.SetActive(true);
        yield return new WaitForSeconds(2.0f);
        Application.Quit();
    }

    /// <summary>
    /// Runs a single pathfinding problem, if the simulation isn't automatic, it waits for user input before every run
    /// </summary>
    /// <returns></returns>
    IEnumerator SimulateOne()
    {
        decomposition = null;
        experimentResults = new ExperimentResults();
        foreach (MovementMode movementMode in movementModesTested)
        {
            InitializeUnits(true);
            if (!automaticSimulation)
            {
                shouldStartSimulation = false;
                while (!shouldStartSimulation)
                {
                    yield return new WaitForSeconds(0.5f);
                }
            }
            Debug.Log($"Pathfinding method: {movementMode} --------------------------------------------------------------");
            this.movementMode = movementMode;
            yield return new WaitForSeconds(0.5f);
            StartPreparation();
            yield return null;
            yield return new WaitForSeconds(0.5f);
            StartWarmUp();
            yield return null;
            yield return new WaitForSeconds(0.5f);

            yield return null;
            yield return new WaitForSeconds(0.5f);

            int i = 0;
            while (i < numberOfRuns)
            {
                failed = false;
                experimentResults.runNumber = i;
                experimentResults.experimentName = simulationSpecifications[simulationID].name;
                experimentResults.movementModeName = movementMode.ToString();
                StartSimulation();
                yield return null;
                while (!simulationFinished) yield return new WaitForSeconds(0.2f);
                if (writeResults) experimentResults.WriteExperimentResultsToFile($"Results/{simulationSpecifications[simulationID].name}/{movementMode}-{i}.txt", failed);
                yield return new WaitForSeconds(1.0f);
                if (i != numberOfRuns - 1)
                {
                    InitializeUnits();
                    if (!automaticSimulation)
                    {
                        shouldStartSimulation = false;
                        while (!shouldStartSimulation)
                        {
                            yield return new WaitForSeconds(0.5f);
                        }
                    }
                }
                i++;
                yield return new WaitForSeconds(1.0f);
            }
            yield return new WaitForSeconds(1.0f);
        }
        if (writeResults && movementModesTested.Count > 0 && numberOfRuns > 0)
        {
            experimentResults.WriteGateAnalysisToFile($"Results/{simulationSpecifications[simulationID].name}/GateAnalysis.txt");
            experimentResults.decomposition = decomposition.regionMap;
            experimentResults.WriteDecompositionToFile($"Results/{simulationSpecifications[simulationID].name}/Decomposition.txt");
        }
    }

    /// <summary>
    /// Initializes places units at the starting positions specified by the simulation specification
    /// </summary>
    /// <param name="forceNew">Forces the program to reinitialize the memory allocated for the units (in ECS).</param>
    private void InitializeUnits(bool forceNew = false)
    {
        List<Unit> units = new List<Unit>();
        List<UnitVisualization> unitVisualizations = new List<UnitVisualization>();
        for (int y = 0; y < simulationSpecifications[simulationID].unitStartMap.height; y++)
        {
            for (int x = 0; x < simulationSpecifications[simulationID].unitStartMap.width; x++)
            {
                Color pixel1 = simulationSpecifications[simulationID].unitStartMap.GetPixel(x, y);
                if (pixel1.r > 0.5)
                {
                    Unit unit = new Unit(units.Count);
                    unit.Initialize(new Vector2(x + 0.5f, y + 0.5f));
                    units.Add(unit);
                    if (unitDisplayMode != UnitDisplay.None)
                    {
                        GameObject go = Instantiate(unitPrefab, new Vector3(x + 0.5f, y + 0.5f, 0.0f), Quaternion.identity, unitsParent.transform);
                        UnitVisualization unitVisualization = go.GetComponent<UnitVisualization>();
                        unitVisualizations.Add(unitVisualization);
                    }
                }
            }
        }

        if (unitDisplayMode != UnitDisplay.None)
            unitMovementManager.SetUnits(units, unitVisualizations, forceNew);
        else
            unitMovementManager.SetUnits(units, forceNew);
    }

    /// <summary>
    /// If the simulation was launched, it calls the UnitMovementManager to move the units.
    /// It also ends the simulations that were running for too long
    /// </summary>
    private void Update()
    {
        if (simulationTime > 10000 && !simulationFinished)
        {
            simulationFinished = true;
            failed = true;
            for (int i = unitMovementManager.units.Count - 1; i >= 0; i--)
            {
                unitMovementManager.RemoveUnit(unitMovementManager.units[i]);
                unitMovementManager.units[i].currentCoord.UnitsAtTile().Remove(unitMovementManager.units[i]);
                foreach (Unit deletedUnit in unitMovementManager.unitsToDelete)
                {
                    unitMovementManager.units.Remove(deletedUnit);
                }
                if (unitMovementManager.unitsToDelete.Count > 0 && unitMovementManager.unitsECS != null)
                {
                    unitMovementManager.unitsECS.UnitsRemoved(unitMovementManager.units);
                }
            }
        }
        if (simulationStarted && !simulationFinished)
        {
            for (int i = 0; i < outerMovementCycles; i++)
            {
                float deltaTime = 0.02f;
                unitMovementManager.MoveUnits(deltaTime, internalMovementCycles);
                simulationTime += deltaTime * internalMovementCycles;
            }
        }
        executionComputationTime += Time.unscaledDeltaTime;
    }
    
    /// <summary>
    /// Unit reached the target. Update the metrics and remove the unit
    /// </summary>
    /// <param name="unit"></param>
    [HideInInspector]
    public void UnitReachedTarget(Unit unit)
    {
        unitsReachedTarget++;
        experimentResults.unitPathsData.unitPaths[unit.ID] = unit.pathPositions;
        experimentResults.unitPathsData.finishTimes[unit.ID] = simulationTime;
        experimentResults.unitPathsData.repaths += unit.repaths;
        experimentResults.unitPathsData.softRepaths += unit.softRepaths;
        experimentResults.gatesData.unitGatePaths[unit.ID] = unit.gatePathMovement;
        if (!halfFinished && unitsReachedTarget >= numberOfUnits * 0.9) {
            experimentResults.finishedTime90 = simulationTime;
            Debug.Log($"90% the units arrived: {simulationTime}s");
            halfFinished = true;
        }
        if (unitsReachedTarget == numberOfUnits)
        {
            experimentResults.finishedTime = simulationTime;
            Debug.Log($"Simulation Finished: {simulationTime}s, Execution Time: {executionComputationTime}");
            simulationFinished = true;
            experimentResults.unitPathsData.ComputeResults(simulationID);
            experimentResults.gatesData.GatesDataFromUnitPaths();
        }
        unitMovementManager.RemoveUnit(unit);
    }

    /// <summary>
    /// Perform pathfinding requests to warm up the algorithm
    /// </summary>
    private void StartWarmUp()
    {
        for (int i = 0; i < warmUpStartPositions.Count; i++)
        {
            for (int j = 1; j < warmUpGoalPositions.Count; j++)
            {
                unitMovementManager.StartWarmUp(movementMode, warmUpStartPositions[i], warmUpGoalPositions[j]);
            }
        }
    }

    /// <summary>
    /// Do the pathfinding (managed in the UnitMovementManager)
    /// </summary>
    private void StartSimulation()
    {
        experimentResults.gatesData.unitGatePaths = new Dictionary<int, List<(int gateID, (float ArrivalTime, float distanceFromStart, int StreamID, Vector2 ArrivalPosition))>>();
        experimentResults.unitPathsData = new UnitPathsData();
        numberOfUnits = unitMovementManager.units.Count;
        unitsReachedTarget = 0;
        simulationFinished = false;
        halfFinished = false;
        simulationStarted = true;

        unitMovementManager.StartMovement(movementMode);
        simulationTime = 0;
        executionComputationTime = 0;
    }

    /// <summary>
    /// Preparations phase - analyze the map
    /// </summary>
    private void StartPreparation()
    {
        System.Diagnostics.Stopwatch stopwatch = new System.Diagnostics.Stopwatch();
        stopwatch.Start();
        switch (movementMode)
        {
            case MovementMode.SupremeCommanderFlowField:
                MapRegionsSupremeCommander tmp = MapRegionsSupremeCommander.Instance;
                break;
            case MovementMode.FlowGraph:
                flowGraphWrapper = new FlowGraphWrapper();
                flowGraphWrapper.Preparation();
                break;
            case MovementMode.RegionalFlowGraph:
                regionalFlowGraphWrapper = new RegionalFlowGraphWrapper();
                regionalFlowGraphWrapper.Preparation();
                break;
            default:
                break;
        }
        stopwatch.Stop();
        Debug.Log($"Preparation time: {stopwatch.Elapsed.TotalMilliseconds} ms");
        experimentResults.preparationTime = stopwatch.Elapsed.TotalMilliseconds;

        if (decomposition == null)
        {
            WaterDecomposition waterDecomposition = new WaterDecomposition();
            decomposition = waterDecomposition.Decompose(Map.instance.passabilityMap, -1);
        }
        DisplayDecomposition();
    }

    /// <summary>
    /// Visualize the gates and regions (if specified by the user)
    /// </summary>
    public void DisplayDecomposition()
    {
        if (decompositionDisplay != DecompositionDisplay.None)
        {
            List<Color> colors = new List<Color>();
            for (int i = 0; i < decomposition.numberOfClusters + 1; i++)
            {
                colors.Add(new Color(UnityEngine.Random.value, UnityEngine.Random.value, UnityEngine.Random.value));
            }
            for (int x = 0; x < decomposition.regionMap.GetLongLength(0); x++)
            {
                for (int y = 0; y < decomposition.regionMap.GetLongLength(1); y++)
                {
                    if (decomposition.regionMap[x, y] != -1)
                    {
                        if (decompositionDisplay == DecompositionDisplay.GatesAndRegions)
                        {
                            if (decomposition.IsGate(decomposition.regionMap[x, y]))
                            {
                                Map.instance.groundTexture.SetPixel(x, y, new Color(0.5f, 0.5f, 1.0f));
                            }
                            else if (decomposition.regionMap[x, y] >= 1000)
                            {
                                Map.instance.groundTexture.SetPixel(x, y, Color.green);
                            }
                            else
                            {
                                Map.instance.groundTexture.SetPixel(x, y, colors[decomposition.regionMap[x, y]]);
                            }
                        }
                        else if (decompositionDisplay == DecompositionDisplay.GatesOnly)
                        {
                            if (decomposition.IsGate(decomposition.regionMap[x, y]))
                            {
                                Map.instance.groundTexture.SetPixel(x, y, new Color(0.5f, 0.5f, 1.0f));
                            }
                            else
                            {
                                Map.instance.groundTexture.SetPixel(x, y, Color.white);
                            }
                        }
                    }
                }
            }
        }
        Map.instance.RedrawTexture();
    }
}

/// <summary>
/// Pathfinding algorithm used by the units
/// </summary>
[System.Serializable]
public enum MovementMode
{
    FlowField,
    [Obsolete]
    AStarEveryUnit,
    AStar,
    [Obsolete]
    SupremeCommanderFlowField,
    [Obsolete]
    RegionalPath,
    FlowGraph,
    RegionalFlowGraph,
    [Obsolete]
    RegionalFlowGraphPaths
}

/// <summary>
/// How should the units be visualized
/// </summary>
public enum UnitDisplay
{
    None,
    SingleColor,
    FlowStreamVisualization
}

/// <summary>
/// How should the map decomposition be visualized
/// </summary>
public enum DecompositionDisplay
{
    None,
    GatesOnly,
    GatesAndRegions
}