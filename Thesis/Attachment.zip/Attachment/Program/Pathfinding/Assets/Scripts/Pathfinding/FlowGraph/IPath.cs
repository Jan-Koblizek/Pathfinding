//Original by Jan Pacovsk�
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

internal interface IPath
{
    float Time { get; }
    float Flow { get; }
}
