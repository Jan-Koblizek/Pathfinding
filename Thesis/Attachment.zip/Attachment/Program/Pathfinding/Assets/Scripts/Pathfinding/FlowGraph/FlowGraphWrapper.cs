using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Class handling different pathfinding stages of the Flow Graph algorithm
/// </summary>
public class FlowGraphWrapper
{
    public RegionalDecomposition decomposition;
    public PartialFlowGraph partialFlowGraph;

    /// <summary>
    /// Do map decomposition and construct a partial flow graph
    /// </summary>
    public void Preparation()
    {
        WaterDecomposition waterDecomposition = new WaterDecomposition();
        decomposition = waterDecomposition.Decompose(Map.instance.passabilityMap, -1);
        Simulator.Instance.decomposition = decomposition;
        partialFlowGraph = PartialFlowGraph.PartialFlowGraphFromDecomposition(decomposition);
    }

    /// <summary>
    /// Process a dummy pathfinding request
    /// </summary>
    /// <param name="units"></param>
    /// <param name="start"></param>
    /// <param name="target"></param>
    public void PathfindingWarmUp(List<Unit> units, Vector2 start, Vector2 target)
    {
        FlowGraph flowGraph = new FlowGraph(partialFlowGraph, start, target, decomposition.regionMap);
        FlowGraphPlanning.StartNewFlowGraphPlanWarmUp(flowGraph, units);
    }

    /// <summary>
    /// Do the Flow grpah pathfinding
    /// </summary>
    /// <param name="units"></param>
    /// <param name="startPosition"></param>
    /// <param name="target"></param>
    public void Pathfinding(List<Unit> units, Vector2 startPosition, Vector2 target)
    {
        FlowGraph flowGraph = new FlowGraph(partialFlowGraph, startPosition, target, decomposition.regionMap);
        FlowGraphPlanning.StartNewFlowGraphPlan(flowGraph, units);
    }
}
