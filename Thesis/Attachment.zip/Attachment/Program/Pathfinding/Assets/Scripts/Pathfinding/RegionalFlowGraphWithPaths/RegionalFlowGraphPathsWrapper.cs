using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class RegionalFlowGraphPathsWrapper
{
    public RegionalDecomposition decomposition;
    public RegionalPathfindingPathsAnalysis regionalPathfindingPaths;
    public PartialFlowGraph partialFlowGraph;
    public List<UnitPathAssignmentRegionalFlowGraph> RFGDistribution;

    public void Preparation()
    {
        WaterDecomposition waterDecomposition = new WaterDecomposition();
        decomposition = waterDecomposition.Decompose(Map.instance.passabilityMap, -1);
        Simulator.Instance.decomposition = decomposition;
        (Dictionary<RegionGateway, Dictionary<RegionGateway, float>> distances, Dictionary<RegionGateway, Dictionary<RegionGateway, List<Vector2>>> paths) pathsAndDistances;
        pathsAndDistances = MapRegionPathfinding.DistancesAndPathsBetweenGates(decomposition);
        regionalPathfindingPaths = new RegionalPathfindingPathsAnalysis(decomposition, pathsAndDistances.paths, pathsAndDistances.distances);
        partialFlowGraph = PartialFlowGraph.PartialFlowGraphFromDecomposition(decomposition, pathsAndDistances.distances);
    }

    public void PathfindingWarmUp(List<Unit> units, Vector2 start, Vector2 target)
    {
        FlowGraph flowGraphRFG = new FlowGraph(partialFlowGraph, start, target, decomposition.regionMap);
        RegionalFlowGraphPlanningUsingSubPaths.StartNewFlowGraphPlanWarmUp(flowGraphRFG, units.ToHashSet());
    }
    public void Pathfinding(List<Unit> units, Vector2 startPosition, Vector2 target)
    {
        FlowGraph flowGraphRFG = new FlowGraph(partialFlowGraph, startPosition, target, decomposition.regionMap);
        RegionalFlowGraphPlanningUsingSubPaths.StartNewFlowGraphPlan(flowGraphRFG, units.ToHashSet());
    }
}