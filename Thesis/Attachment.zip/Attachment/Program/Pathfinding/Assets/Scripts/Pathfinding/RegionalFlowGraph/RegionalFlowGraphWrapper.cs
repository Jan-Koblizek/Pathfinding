using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

/// <summary>
/// Class calling different parts of the Regional Flow Graph Algorithm
/// </summary>
public class RegionalFlowGraphWrapper
{
    public RegionalDecomposition decomposition;
    public RegionalPathfindingAnalysis regionalPathfinding;
    public PartialFlowGraph partialFlowGraph;
    public List<UnitPathAssignmentRegionalFlowGraph> RFGDistribution;

    public void Preparation()
    {
        WaterDecomposition waterDecomposition = new WaterDecomposition();
        decomposition = waterDecomposition.Decompose(Map.instance.passabilityMap, -1);
        Simulator.Instance.decomposition = decomposition;
        List<(Vector2 flowDirection, float distanceToGate)[,]> flowMaps2 = MapRegionPathfinding.CreateFlowMaps(decomposition);
        Dictionary<RegionGateway, Dictionary<RegionGateway, float>> distances2 = MapRegionPathfinding.DistancesBetweenGates(decomposition);
        regionalPathfinding = new RegionalPathfindingAnalysis(decomposition, flowMaps2, distances2);
        partialFlowGraph = PartialFlowGraph.PartialFlowGraphFromDecomposition(decomposition, distances2);
    }

    public void PathfindingWarmUp(List<Unit> units, Vector2 start, Vector2 target)
    {
        FlowGraph flowGraphRFG = new FlowGraph(partialFlowGraph, start, target, decomposition.regionMap, regionalPathfinding);
        RegionalFlowGraphPlanning.StartNewFlowGraphPlanWarmUp(flowGraphRFG, units.ToHashSet());
    }
    public void Pathfinding(List<Unit> units, Vector2 startPosition, Vector2 target)
    {
        FlowGraph flowGraphRFG = new FlowGraph(partialFlowGraph, startPosition, target, decomposition.regionMap, regionalPathfinding);
        RegionalFlowGraphPlanning.StartNewFlowGraphPlan(flowGraphRFG, units.ToHashSet(), out RFGDistribution);
    }
}
