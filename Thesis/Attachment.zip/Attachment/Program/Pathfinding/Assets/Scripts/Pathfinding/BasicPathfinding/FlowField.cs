using UnityEngine;

public class FlowField
{
    private Vector2[,] flowField;

    /// <summary>
    /// Weighted sum of the directions from nearby coords
    /// </summary>
    /// <param name="pos"></param>
    /// <returns></returns>
    public Vector2 getMovementDirection(Vector2 pos)
    {
        Coord ff = new Coord(Mathf.FloorToInt(pos.x), Mathf.FloorToInt(pos.y));
        Coord fc = new Coord(Mathf.FloorToInt(pos.x), Mathf.Min(Mathf.CeilToInt(pos.y), flowField.GetLength(1)-1));
        Coord cf = new Coord(Mathf.Min(Mathf.CeilToInt(pos.x), flowField.GetLength(0)-1), Mathf.FloorToInt(pos.y));
        Coord cc = new Coord(Mathf.Min(Mathf.CeilToInt(pos.x), flowField.GetLength(0)-1), Mathf.Min(Mathf.CeilToInt(pos.y), flowField.GetLength(1)-1));
        float strengthFF = 1.5f - Vector2.Distance(pos, new Vector2(ff.X, ff.Y));
        float strengthFC = 1.5f - Vector2.Distance(pos, new Vector2(fc.X, fc.Y));
        float strengthCF = 1.5f - Vector2.Distance(pos, new Vector2(cf.X, cf.Y));
        float strengthCC = 1.5f - Vector2.Distance(pos, new Vector2(cc.X, cc.Y));

        Vector2 flowFF = flowField[ff.X, ff.Y] * strengthFF;
        Vector2 flowFC = flowField[fc.X, fc.Y] * strengthFC;
        Vector2 flowCF = flowField[cf.X, cf.Y] * strengthCF;
        Vector2 flowCC = flowField[cc.X, cc.Y] * strengthCC;

        return (flowFF + flowFC + flowCF + flowCC).normalized;
    }

    public FlowField(Coord targetCoord)
    {
        flowField = Pathfinding.ConstructFlowField(targetCoord);
    }
}
