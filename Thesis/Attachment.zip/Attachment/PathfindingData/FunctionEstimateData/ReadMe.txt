Data used for the flow function estimate.

It comes only from a selected few maps. 
These maps were simple enough for us to obtain valid incoming flow and overflow data.