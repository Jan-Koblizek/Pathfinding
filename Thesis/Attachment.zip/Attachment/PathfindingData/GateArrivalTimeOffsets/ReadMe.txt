Gate Arrival Time Data - not humanly readable no information about the maps or gate identifiers.
Data for RFG algorithm

allOffsets.csv - differences between the predicted arrival time and the real arrival time (real - predicted)
allOffsetPercents.csv - relative offsets (offset / predicted arrival)
firstGateOffsets.csv - like allOffsets but only for gates whose predecessor is the units' origin
adjustedOffsets.csv - offsets adjusted for the offsets at the first gate
adjustedOffsets.csv - like allOffsetPercents but with adjusted offsets